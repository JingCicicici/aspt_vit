# models/baselines/vit_plain_cifar10.py
from models.components.vit_core import create_plain_vit_cifar10

def create_vit_plain_cifar10():
    return create_plain_vit_cifar10()
